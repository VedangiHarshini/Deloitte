package emp.dao;
import java.util.List;

import emp.Employee;

public interface EmployeeDAO {
	public boolean insertEmployee(Employee employee);
}

