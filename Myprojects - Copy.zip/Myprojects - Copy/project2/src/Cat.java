
public class Cat extends Animal{
		 public void eat() {
			 
			 System.out.println("eats fish");
			 System.out.println("meow");
		 }
	}