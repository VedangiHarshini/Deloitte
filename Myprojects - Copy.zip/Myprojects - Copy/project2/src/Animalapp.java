
public class Animalapp {
	
	public static void main(String[] args) {
	Animal a = new Animal();
	a.eat();
	Cat c = new Cat();
	Animal g =new Cat();
	c.eat();
	g.eat();
	}
 
	 
	 
	 

}
