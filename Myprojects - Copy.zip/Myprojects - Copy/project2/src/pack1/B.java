package pack1;

public class B extends A {
	public int i;
	public void test()
	{
		A a = new A();
		a.i=1;
		i=2;	
	}
}
