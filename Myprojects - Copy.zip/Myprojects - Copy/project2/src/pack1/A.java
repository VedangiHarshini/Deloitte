package pack1;

public class A {
	public int i;
	
	public void test()
	{
		A a = new A();
		a.i=1;
		i=2;
		System.out.println(i);
	}
	public static void main(String[] args)
	{
		
		A a = new A();
		a.test();
	}
}
