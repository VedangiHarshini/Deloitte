
public class Animal{
	 public void eat() {
		 System.out.println("Eats food");
		 System.out.println("they sound");
	 }
}
