package pack2;

import pack1.A;

public class D {
	public int i;
	public void test()
	{
		A a = new A();
		a.i=1;
		i=2;
		
	}
}
