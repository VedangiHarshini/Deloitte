package collectiondemos;
import java.util.TreeSet;
public class Demo7 {
	public static void main(String[] args) {
		TreeSet n= new TreeSet();
		n.add(234);
		n.add(34);
		n.add(2347);
		System.out.println(n);
	}

}
