package stringdemos;

public class Demo1 {
	public static void main(String[] args) {
		String name = new String("Harshini");
		System.out.println(name.length());
		System.out.println(name.concat("Vedangi"));
		System.out.println(name.substring(3,5));
		System.out.println(name.charAt(4));
		System.out.println(name.endsWith("ni"));
		
	}

}
