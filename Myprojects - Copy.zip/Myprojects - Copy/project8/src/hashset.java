import java.util.*;
class hashset
{
public static void main(String args[])
{
HashSet<String> hashset1 = new HashSet<String>();
hashset1.add("Item 0");
hashset1.add("Item 1");
hashset1.add("Item 2");
hashset1.add("Item 3");
hashset1.add("Item 4");
hashset1.add("Item 5");
hashset1.add("Item 6");
System.out.println(hashset1);
}
}
