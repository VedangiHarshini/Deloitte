package com.oracle.springtraining.coupling1.factorysolution;

public interface Account {
	
		public String getDetails();
}
