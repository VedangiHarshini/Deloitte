package zoo;
import org.animals.*;
public class VandalurZoo {
	public static void main(String args[]){
	Lion l = new Lion();
	l.isVegetarian();
	l.canClimb();
	l.getSound();
	Monkey m= new Monkey();
	m.isVegetarian();
	m.canClimb();
	m.getSound();
	Elephant e = new Elephant();
	e.isVegetarian();
	e.canClimb();
	e.getSound();
}
}
	
	
	
	
	
	


