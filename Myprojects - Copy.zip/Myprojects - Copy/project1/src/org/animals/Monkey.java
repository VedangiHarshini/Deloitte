package org.animals;

public class Monkey {
	
    public void isVegetarian()
    {
    	System.out.println("Eats grass");
    }
    public void canClimb()
    {
    	System.out.println("they can climb");
    }
    public void getSound()
    {
    	System.out.println("yes");
    }
}
