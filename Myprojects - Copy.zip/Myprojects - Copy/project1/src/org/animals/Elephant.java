package org.animals;

public class Elephant {
	
    public void isVegetarian()
    {
    	System.out.println("Eats grass");
    }
    public void canClimb()
    {
    	System.out.println("nope");
    }
    public void getSound()
    {
    	System.out.println("sounds");
    }
}
