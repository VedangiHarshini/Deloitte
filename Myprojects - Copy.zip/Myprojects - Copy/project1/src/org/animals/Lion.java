package org.animals;

public class Lion {
	
    public void isVegetarian()
    {
    	System.out.println("no");
    }
    public void canClimb()
    {
    	System.out.println("they cant climb");
    }
    public void getSound()
    {
    	System.out.println("they do sound");
    }
}
