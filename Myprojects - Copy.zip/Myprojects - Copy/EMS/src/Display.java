
public class Display {
	public void hello()
	{
	System.out.println(" hello");
	}
	public void hi()
	{
		System.out.println("hi ");	
	}
}
