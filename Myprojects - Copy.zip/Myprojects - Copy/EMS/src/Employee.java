
public class Employee {
	public void employeeDetails()
	{
		System.out.println("these are employee details");
	}

}
