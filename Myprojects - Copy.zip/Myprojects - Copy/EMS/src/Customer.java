
public class Customer {
	public void customerDetails()
	{
		System.out.println("these are the customer details");
	}
	

}
