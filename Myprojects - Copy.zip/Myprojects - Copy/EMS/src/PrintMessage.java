
public class PrintMessage {
	public static void main(String[] args) {
	//System.out.println("Hello and welcome to IDE");
	Display p = new Display();
	p.hello();
	p.hi();
	Customer c = new Customer();
	c.customerDetails();
	Employee e = new Employee();
	e.employeeDetails();
}
}

	
